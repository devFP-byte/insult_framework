//
//  FPMacro.h
//  Feedback
//
//  Created by 李焱 on 2021/4/16.
//

#ifndef FPMacro_h
#define FPMacro_h
#import "ToolUtil.h"
#import "NSBundle+SdkBundle.h"

#define IS_IPAD     [ToolUtil isIpad]

#define LOCALE_STR(key)  [NSBundle fp_localizedStringForKey:key]

#endif /* FPMacro_h */
