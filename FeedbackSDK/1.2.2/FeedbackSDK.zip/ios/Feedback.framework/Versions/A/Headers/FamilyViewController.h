//
//  FamilyViewController.h
//  AFNetworking
//
//  Created by 李焱 on 2021/4/9.
//

#import <UIKit/UIKit.h>
#import "FamilyViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FamilyViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
