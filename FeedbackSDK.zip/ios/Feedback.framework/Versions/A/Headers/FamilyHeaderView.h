//
//  FamilyHeaderView.h
//  Feedback
//
//  Created by 李焱 on 2021/4/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol FamilyHeaderViewDelegate <NSObject>

- (void)closeBtnClick;
- (void)shareBtnClick;
- (void)adviseBtnClick;

@end

@interface FamilyHeaderView : UICollectionReusableView

@property(nonatomic, weak) id<FamilyHeaderViewDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
