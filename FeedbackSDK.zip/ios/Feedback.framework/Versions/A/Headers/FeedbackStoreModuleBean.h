//
//  FeedbackStoreModuleBean.h
//  Feedback
//
//  Created by 李焱 on 2021/4/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FeedbackStoreModuleBean : NSObject

@property(nonatomic, strong) NSString *moduleId;

@property(nonatomic, strong) NSString *title;

@property(nonatomic, strong) NSString *desc;

@property(nonatomic, strong) NSString *skipUrl;

@property(nonatomic, strong) NSArray *publicityPicUrl;

@property(nonatomic, strong) NSString *logoUrl;

+ (NSArray *)transforModuleBeans:(NSData *)data;

@end

NS_ASSUME_NONNULL_END
