//
//  FPMacro.h
//  Feedback
//
//  Created by 李焱 on 2021/4/16.
//

#ifndef FPMacro_h
#define FPMacro_h
#import "ToolUtil.h"

#define IS_IPAD     [ToolUtil isIpad]

#endif /* FPMacro_h */
