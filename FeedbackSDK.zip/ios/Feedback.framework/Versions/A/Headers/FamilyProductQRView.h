//
//  FamilyProductQRView.h
//  Feedback
//
//  Created by 李焱 on 2021/4/23.
//

#import <UIKit/UIKit.h>
#import "FeedbackStoreModuleBean.h"

NS_ASSUME_NONNULL_BEGIN

@interface FamilyProductQRView : UIView

- (void)setupProductBean:(FeedbackStoreModuleBean *)bean;

@end

NS_ASSUME_NONNULL_END
